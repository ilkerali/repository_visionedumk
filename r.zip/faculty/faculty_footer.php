        </div>
    </main>

    <!-- Footer (Optional) -->
    <footer style="background: var(--white); border-top: 1px solid var(--gray-200); padding: var(--spacing-lg); text-align: center; color: var(--gray-600); font-size: 0.875rem; margin-top: var(--spacing-2xl);">
        <p>&copy; <?php echo date('Y'); ?> International Vision University. All rights reserved.</p>
    </footer>

    <!-- JavaScript Files -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
