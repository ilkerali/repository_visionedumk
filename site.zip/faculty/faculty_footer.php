        </div>
    </main>

    <!-- Footer -->
    <footer style="background: #2c3e50; color: white; padding: 1.5rem 0; margin-top: 3rem; text-align: center;">
        <div class="container">
            <p style="margin: 0.5rem 0; font-size: 0.9rem;">&copy; <?php echo date('Y'); ?> International Vision University. All rights reserved.</p>
            <p style="margin: 0.5rem 0; font-size: 0.9rem;">
                <a href="mailto:ilker@vision.edu.mk" style="color: white; text-decoration: none;">Technical Support</a> | 
                <a href="https://vision.edu.mk" target="_blank" style="color: white; text-decoration: none;">University Website</a>
            </p>
        </div>
    </footer>

    <script src="../assets/js/main.js"></script>
</body>
</html>
