<?php
// Gerekli dosyalar
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

startSession();

// Kullanıcı girişi kontrolü
if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit;
}

$pdo = getDBConnection();

$errors = [];
$success = false;

// Form gönderildiyse
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Formdan gelen veriler
    $title       = trim($_POST['title'] ?? '');
    $authors     = trim($_POST['authors'] ?? '');
    $journal     = trim($_POST['journal'] ?? '');
    $year        = trim($_POST['year'] ?? '');
    $volume      = trim($_POST['volume'] ?? '');
    $issue       = trim($_POST['issue'] ?? '');
    $pages       = trim($_POST['pages'] ?? '');
    $doi         = trim($_POST['doi'] ?? '');
    $language    = trim($_POST['language'] ?? '');
    $abstract    = trim($_POST['abstract'] ?? '');
    $keywords    = trim($_POST['keywords'] ?? '');

    // Basit doğrulamalar
    if ($title === '') {
        $errors[] = 'Article title is required.';
    }

    if ($authors === '') {
        $errors[] = 'Author name(s) are required.';
    }

    if ($year !== '' && !preg_match('/^[0-9]{4}$/', $year)) {
        $errors[] = 'Year must be a 4-digit number (e.g. 2024).';
    }

    // Hata yoksa kaydet
    if (empty($errors)) {
        try {
            // Yayın türü (article) için id bul
            $stmt = $pdo->prepare("
                SELECT id 
                FROM publication_types 
                WHERE slug = :slug OR name = :name 
                LIMIT 1
            ");
            $stmt->execute([
                ':slug' => 'article',
                ':name' => 'Article'
            ]);
            $type = $stmt->fetch(PDO::FETCH_ASSOC);

            // Bulunamazsa varsayılan 1 kullan (kendi tablona göre güncelle)
            $publication_type_id = $type ? $type['id'] : 1;

            $user_id = $_SESSION['user_id'] ?? null;

            // publications tablosuna ekleme
            // Kolon isimlerini kendi veritabanına göre uyarlamayı unutma
            $insert = $pdo->prepare("
                INSERT INTO publications 
                    (user_id, publication_type_id, title, authors, journal_name, publication_year,
                     volume, issue, pages, doi, language, abstract, keywords, created_at)
                VALUES 
                    (:user_id, :type_id, :title, :authors, :journal_name, :year,
                     :volume, :issue, :pages, :doi, :language, :abstract, :keywords, NOW())
            ");

            $insert->execute([
                ':user_id'      => $user_id,
                ':type_id'      => $publication_type_id,
                ':title'        => $title,
                ':authors'      => $authors,
                ':journal_name' => $journal,
                ':year'         => $year ?: null,
                ':volume'       => $volume ?: null,
                ':issue'        => $issue ?: null,
                ':pages'        => $pages ?: null,
                ':doi'          => $doi ?: null,
                ':language'     => $language ?: null,
                ':abstract'     => $abstract ?: null,
                ':keywords'     => $keywords ?: null,
            ]);

            // Aktivite kaydı (tablo yapını kontrol et)
            $log = $pdo->prepare("
                INSERT INTO activity_log (user_id, action, details, created_at)
                VALUES (:user_id, :action, :details, NOW())
            ");
            $log->execute([
                ':user_id' => $user_id,
                ':action'  => 'publication_created',
                ':details' => 'New article added: ' . $title
            ]);

            $success = true;

            // Form alanlarını temizle
            $title = $authors = $journal = $year = $volume = $issue =
            $pages = $doi = $language = $abstract = $keywords = '';

        } catch (Exception $e) {
            $errors[] = 'An error occurred while saving the record: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Article - Academic Publication Repository</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="page-container" style="max-width: 960px; margin: 2rem auto; background: #fff; padding: 2rem; border-radius: 1rem; box-shadow: 0 10px 25px rgba(15,23,42,0.08);">

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
        <div>
            <h1>Add Article</h1>
            <p>You can add a new journal article to the repository using the form below.</p>
        </div>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Back to Dashboard</a>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <ul style="margin-left:1.25rem;">
                <?php foreach ($errors as $err): ?>
                    <li><?= sanitize($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            The article has been saved successfully.
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label>Article Title <span style="color:#ef4444">*</span></label>
            <input type="text" name="title" value="<?= sanitize($title ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Author(s) <span style="color:#ef4444">*</span></label>
            <input type="text" name="authors"
                   placeholder="Name SURNAME, Name SURNAME"
                   value="<?= sanitize($authors ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Journal Name</label>
            <input type="text" name="journal" value="<?= sanitize($journal ?? '') ?>">
        </div>

        <div style="display:flex; gap:1rem; flex-wrap:wrap;">
            <div class="form-group" style="flex:1; min-width:120px;">
                <label>Publication Year</label>
                <input type="number" name="year" min="1900" max="2100" value="<?= sanitize($year ?? '') ?>">
            </div>
            <div class="form-group" style="flex:1; min-width:120px;">
                <label>Volume</label>
                <input type="text" name="volume" value="<?= sanitize($volume ?? '') ?>">
            </div>
            <div class="form-group" style="flex:1; min-width:120px;">
                <label>Issue</label>
                <input type="text" name="issue" value="<?= sanitize($issue ?? '') ?>">
            </div>
        </div>

        <div class="form-group">
            <label>Page Range</label>
            <input type="text" name="pages" placeholder="123-135" value="<?= sanitize($pages ?? '') ?>">
        </div>

        <div class="form-group">
            <label>DOI</label>
            <input type="text" name="doi" value="<?= sanitize($doi ?? '') ?>">
        </div>

        <div class="form-group">
            <label>Language</label>
            <input type="text" name="language" placeholder="English, Turkish, ..." value="<?= sanitize($language ?? '') ?>">
        </div>

        <div class="form-group">
            <label>Abstract</label>
            <textarea name="abstract"><?= sanitize($abstract ?? '') ?></textarea>
        </div>

        <div class="form-group">
            <label>Keywords</label>
            <input type="text" name="keywords" placeholder="separate with commas"
                   value="<?= sanitize($keywords ?? '') ?>">
        </div>

        <button type="submit" class="btn btn-primary">Save Article</button>
        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
